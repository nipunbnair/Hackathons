package OOPProject;

import java.util.Scanner;

public class Auction extends Player                              //Concept 4: Single Inheritance
{   int purse;
   static String teamname;                                      //Concept 5: Static keyword
    int password;
	
	void IPLAuction()
     {    purse=3000;
		 String selection;
         String choice;
         double a1;
         int count=0;
		
         Player P1=new Player();
         
    
		Scanner sc1=new Scanner(System.in);                                          //Concept 6: Usage of Scanner class
		System.out.println("Enter Team no you are interested in (1.CSK 2.SRH 3.RCB 4.DC):");
        int tc = sc1.nextInt();
        switch(tc)
        {
        case 1:teamname="CSK";                                                   //Concept 7: Switch case
                 break;
        case 2:teamname="SRH";
                 break;
        case 3:teamname="RCB";
               break;
        case 4:teamname="SRH";
                 break;
        default: teamname="RR";         
        }
        System.out.println("Enter password: ");
        password = sc1.nextInt();
        
       while (!(password==2022))
       {
         System.out.println("You entered the wrong password");
         System.out.println("Enter password:");
         password = sc1.nextInt();
       }
        System.out.println("Do you want to participate in the Auction of IPL 2022?(Y/N)");
         choice=sc1.next();
    	 if("Y".equalsIgnoreCase(choice))
    		 { 
    		     for(int i=1;i<=30;i++)
    		     {
    		     P1.displayplayer(i);
    		     System.out.println("Are you interested in buying this player?(Y/N)");
    		     selection=sc1.next();
    		     	if("Y".equals(selection))                                                                  //Concept 8: Nested if
    		     {
    		    	 System.out.println("You are leading the bid");
    		    	 P1.salary[i-1]+=5;
    		    	 P1.Team[i-1]=teamname; 
    		    	 while("Y".equals(selection)) 
    		    	 {
    		    		 P1.salary[i-1]+=5;
    		    		 a1 = 4*Math.random();                                                                  //Concept 9: Math class functions random() and round()
    		    		 if (a1 >=0 && a1 < 1)
    		    		 	{	
    		    			 P1.Team[i-1]="MI";
    		    			 P1.salary[i-1]+=5;
    		    			 System.out.println("MI is leading in the bid with"+P1.salary[i-1]);
    		    		 	}
    		    		 else if (a1 >=1 && a1 < 2)
    		    		 	{
    		    			 P1.Team[i-1]="KKR";
    		    			 P1.salary[i-1]+=5;
    		    			 System.out.println("KKR is leading in the bid with"+P1.salary[i-1]);
    		    		 	}
    		    		 else if (a1 >=2 && a1 < 3)
    		    		 {	
    		    			 P1.Team[i-1]="PKS";
    		    			 P1.salary[i-1]+=5;
    		    			 System.out.println("PKS is leading in the bid with"+P1.salary[i-1]);
    		    		 }
    		    		 else if (a1 >=3 && a1 <= 4)
    		    		 { 
    		    			 P1.salary[i-1]+=5;
    		    			 purse=purse-P1.salary[i-1];
    		    		     if(purse<0)
 		    		 		{System.out.println("You have run out of money you may not purchase any more  players");
 		    		 		 P1.Team[i-1]="Unsold";
 		    		 		 P1.displayteam(teamname);
 		    		 		 System.out.println("The Auction is over for you...Exiting the Auction");
 		    		 		 System.exit(0);
 		    		 		}                                                                                      //Concept 10: Exiting or terminating program
    		    			 if (!"IND".equals(P1.Nationality[i-1]))
    		    			 {
    		    				 count++;
    		    				 System.out.println("player selected");
    		    				 P1.Team[i-1]=teamname;                                 //Our team
        		    			 System.out.println("You have won the bid.The player is sold");
        		    			 System.out.println(P1.PName[i-1]+"was sold at"+P1.salary[i-1]);
        		    			 System.out.println("The remaining purse available is "+purse);
    		    			     if(count==6)
    		    			     {
    		    				 System.out.println("Your limit on Foreign players has reached You may not buy anymore overseas players");
    		    			     }
    		    			    try
    		    			    {
    		    				 if(count>6)
    		    				 {   P1.Team[i-1]="Unsold";
    		    				     System.out.println("You cannot buy this player");
    		    				     System.out.println(P1.PName[i-1]+"	remains unsold");
    		    					 throw new ForeignUpperLimit("limit reached");               //Concept 11: User defined Exception
    		    				 }
    		    			    }
    		    			      catch(ForeignUpperLimit f)
    		    			    	{
    		    			    	  System.out.println(f);
    		    			    	} 
    		    			    
    		    			   }  
    		    			 else
    		    			 { 
    		    		     System.out.println("player selected");
    		    		    
		    				 P1.Team[i-1]=teamname;                                 //Our team
    		    			 System.out.println("You have won the bid.The player is sold");
    		    			 System.out.println(P1.PName[i-1]+"	was sold at	"+P1.salary[i-1]);
    		    			 System.out.println("The remaining purse available is "+purse);
    		    			 }
    		    			 break;
    		    		 }
    		    		 System.out.println("Are you interested in continuing with the bid?(Y/N)");
    		    		 selection=sc1.next();
    		    	 }
    		     }
    		     if("N".equals(selection))
    		     {
    		    	 a1 = 3*Math.random(); 
    		    	
   		          	 if (a1 >=0 && a1 < 1)
   		             {
   		          		 P1.Team[i-1]="MI";
   		                 P1.salary[i-1]+=Math.round(100*a1*5);
   		                 System.out.println("MI won the bid");
   		                 System.out.println(P1.PName[i-1]+"was sold at"+P1.salary[i-1]);
   		             }
   		          	 else if (a1 >=1 && a1 < 2)
   		          	 {
   		          		 P1.Team[i-1]="KKR";
   		          		 P1.salary[i-1]+=Math.round(100*a1*5);
   		          		 System.out.println("KKR won the bid");
   		          		 System.out.println(P1.PName[i-1]+"was sold at"+P1.salary[i-1]);
   		          	 }
   		          	 else if (a1 >=2 && a1 < 3)
   		          	 {
   		          		 P1.Team[i-1]="PKS";
   		          		 P1.salary[i-1]+=Math.round(100*a1*5);
   		          		 System.out.println("PKS won the bid");
   		          		 System.out.println(P1.PName[i-1]+"was sold at"+P1.salary[i-1]);
   		          	 }
   		         }
    		}
    	    //System.out.println("Do you want to continue to participate in the Auction of IPL 2021?(Y/N)");
    		//choice=sc1.next();  
    		//if("N".equals(choice))
    		P1.displayteam(teamname);//Here display your team
    		
       }
    sc1.close();
    }
      	 
	 public static void main(String[] args) 
	{			
		Auction A1=new Auction();	                   //Concept 12 : Object creation
        A1.IPLAuction();
	}
}
     class ForeignUpperLimit extends Exception
     {
    	 public ForeignUpperLimit(String s)
    	 {
    		 super(s);                                //Concept 13: Usage of super keyword
    	 }
     }
