package OOPProject;

public class Player 
{                                         
	int[] Slno;
	String[] PName;
	int[] age;
	int[] basePrice;
	int[] noofMatches;
	String[] Nationality;
	int[] salary;
	String[] Team;
	String[] Type;
	int[] Wkts;
	int[] Runs;
	double[] StrikeRate;
	void displayplayer(int a)
	{
		for(int i=1;i<=30;i++)                                         //Concept 1:Loops
		{   
			if(a==Slno[i-1])
			{
				System.out.println("Player Name: "+PName[i-1]);
				System.out.println("Age: "+age[i-1]);
				System.out.println("Nationality: "+Nationality[i-1]);
				System.out.println("Base Price: "+basePrice[i-1]);
				System.out.println("Number of Matches: "+noofMatches[i-1]);
				System.out.println("Type of Player: "+Type[i-1]);
				System.out.println("Wickets taken: "+Wkts[i-1]);
				System.out.println("Runs scored:  "+Runs[i-1]);
				System.out.println("Strike Rate: "+StrikeRate[i-1]);
			}                                                                      //Fetch details from a file 
		}
	}         
void displayteam(String team)
{
	for(int i=1;i<=30;i++)                                            
	{  
		if(team.equals(Team[i-1]))
		{
			System.out.println("	Player Name: "+PName[i-1]+ "	Age: " +age[i-1]+"	Type of Player: "+Type[i-1]+"	 Nationality: "+Nationality[i-1]+"	Team: "+Team[i-1]+"	Salary: "+salary[i-1]);
			
		}
	}
}  

                                                                             //Concept 2: Constructor
Player()                                                                    //Concept 3: Arrays
{
	Slno = new int[]{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30};
	PName=new String[]{"Dawid Malan","Virat Kohli","Rishabh Pant", "KL Rahul" , "Aaron Finch", "Colin Munro" ,"Rohit Sharma", "Suresh Raina", "Suryakumar Yadav","Manish Pandey","Rashid Khan", "Adam Zampa"," R Ashwin"," R Jadeja","Tim Southee", "Trent Boult","Chris Jordan","Umesh Yadav", "Ishant Sharma","Y Chahal","Glenn Maxwell","Mohummad Nabi"," Shakib Al Hasan","Shivam Dube", "Vijay Shankar"," Hardik Pandya ","Krunal Pandya"," Axar Patel","Harshal Patel"," Kedar Jadhav" };
 	age=new int [] {33,32,23,28,34,33,33,34,30,31,22,28,34,32,32,31,32,33,32,30,32,36,33,27,30,27,29,27,30,35};
 	basePrice=new int[] {200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200};
 	noofMatches=new int[] {19,85,28,45,68,65,108,78,0,39,48,38,46,50,77,31,55,7,14,45,69,75,76,13,9,38,18,11,6,9};
 	Nationality=new String[] {"ENG","IND","IND","IND","AUS","NZD","IND","IND","IND","IND","AFG","AUS","IND","IND","NZD","NZD","END","IND","IND","IND","AUS","AFG","BAN","IND","IND","IND","IND","IND","IND","IND"};
 	Team=new String[] {"Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold","Unsold"};
 	Type=new String[] {"Batsman","Batsman","Keeper","Keeper","Batsman","Batsman","Batsman","Batsman","Batsman","Batsman","Bowler","Bowler","Bowler","Bowler","Bowler","Bowler","Bowler","Bowler","Bowler","Bowler","All-rounders","All-rounders","All-rounders","All-rounders","All-rounders","All-rounders","All-rounders","All-rounders","All-rounders","All-rounders"};
 	Wkts=new int[] {0,0,0,0,0,0,0,0,0,0,89,38,52,39,90,41,66,9,8,59,29,69,92,5,5,38,14,9,0,27};
 	Runs=new int[] {855,2928,410,1542,2162,1724,2773,1605,0,709,0,0,0,0,0,0,0,0,0,0,1691,1347,1567,105,101,388,121,68,0,122};
 	salary=new int[] {200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200};
 	StrikeRate=new double[] {149.48,138.44,162.69,129.34,88.16,156.4,138.78,138.87,0.00,126.16,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,158.79,158.46,107.14,136.36,127.73,130.90,191.12,125.93,0.00,123.23};
}

}
